/**
 * @addtogroup OVAL
 * @{
 * @addtogroup OVALAGENT
 * OVAL Agent interface
 *
 * This is a high level API for system probing and OVAL Definition content evaluation.
 * @{
 *
 * @file
 *
 * @author "Peter Vrabec" <pvrabec@gmail.com>
 */

/*
 * Copyright 2010,2011 Red Hat Inc., Durham, North Carolina.
 * All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


#ifndef OVAL_AGENT_XCCDF_API_H_
#define OVAL_AGENT_XCCDF_API_H_

#include "oval_agent_api.h"
#include "xccdf_policy.h"


/**
 * @param policy XCCDF Policy that is being evaluated
 * @param rule_id ID of XCCDF Rule
 * @param id ID of OVAL definition
 * @param it XCCDF Value Binding iterator with value bindings
 * @param usr Void pointer to the user data structure
 * @return XCCDF test result type of evaluated rule
 *
 */
typedef xccdf_test_result_type_t (xccdf_policy_eval_rule_cb_t) (struct xccdf_policy * policy, const char * rule_id,
        const char * id, struct xccdf_value_binding_iterator * it, void * usr);

/**
 * Internal OVAL Agent Callback that can be used to evaluate XCCDF content.
 * \par Example
 * Next example shows common use of this function in evaluation proccess of XCCDF file.
 * \par
 * \code
 *  struct oval_definition_model * def_model = oval_definition_model_import(oval_file);
 *  struct xccdf_benchmark * benchmark = xccdf_benchmark_import(file);
 *  struct xccdf_policy_model * policy_model = xccdf_policy_model_new(benchmark);
 *  struct oval_agent_session * sess = oval_agent_new_session(def_model, "name-of-file");
 *  ...
 *  xccdf_policy_model_register_engine_callback(policy_model, "http://oval.mitre.org/XMLSchema/oval-definitions-5", oval_agent_eval_rule, (void *) sess);
 * \endcode
 * 
 */
xccdf_test_result_type_t oval_agent_eval_rule(struct xccdf_policy * policy, const char * rule_id, const char * id, const char * href,
		struct xccdf_value_binding_iterator * it,
		struct xccdf_check_import_iterator * check_import_it,
		void * usr);

/**
 * Resolve variables from XCCDF Value Bindings and set their values to OVAL Variables
 * @param session OVAL Agent Session
 * @param it XCCDF Value Bindng iterator
 * @return 0 if resolving pass
 * \par Example
 * Example in oval_agent.c in function oval_agent_eval_rule
 */
int oval_agent_resolve_variables(struct oval_agent_session * session, struct xccdf_value_binding_iterator *it);


/**
 * Function to register predefined oval callback for XCCDF evaluation proccess
 * @param model XCCDF Policy Model
 * @param sess oval_agent_session_t parameter for passing session data to callback
 * @memberof xccdf_policy_model
 * @return true if callback registered succesfully, false otherwise
 */
bool xccdf_policy_model_register_engine_oval(struct xccdf_policy_model * model, struct oval_agent_session * sess);

/**
 * @deprecated
 * Transform OVAL Sysinfo into XCCDF Test Result
 * This function has been deprecated, please use xccdf_result_fill_sysinfo(..) instead
 *
 * @param session OVAL Agent session
 * @param ritem XCCDF Result
 */
void oval_agent_export_sysinfo_to_xccdf_result(struct oval_agent_session * session, struct xccdf_result * ritem);

/**
 * @} END OVALDEF
 * @} END OVALAGENT
 */
#endif				/**OVAL_AGENT_XCCDF_API_H_ */


