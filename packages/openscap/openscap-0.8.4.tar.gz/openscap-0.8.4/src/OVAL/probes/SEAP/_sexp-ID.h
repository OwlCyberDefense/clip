#ifndef _SEXP_ID_H
#define _SEXP_ID_H

#include "public/sexp-ID.h"

typedef struct {
	SEXP_ID_t hash;
	int       part;
} __IDres_pair;

#endif /* _SEXP_ID_H */
